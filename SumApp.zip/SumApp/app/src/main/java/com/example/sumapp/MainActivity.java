package com.example.sumapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etNo1,etNo2;
    TextView Result;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNo1 = findViewById(R.id.etNo1);
        etNo2 = findViewById(R.id.etNo2);
        Result = findViewById(R.id.Result);
        btn = findViewById(R.id.btn);

        Result.setVisibility(View.GONE);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int a = Integer.parseInt(etNo1.getText().toString());
                int b = Integer.parseInt(etNo2.getText().toString());
                int c = a+b;
                Result.setText(Integer.toString(c));
                Result.setVisibility(View.VISIBLE);
            }
        });
    }
}